print(a, b)
