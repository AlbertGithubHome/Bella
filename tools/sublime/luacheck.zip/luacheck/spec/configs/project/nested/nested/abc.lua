print(a, b, c)
